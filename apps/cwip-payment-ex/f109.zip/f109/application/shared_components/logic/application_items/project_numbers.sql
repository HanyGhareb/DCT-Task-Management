prompt --application/shared_components/logic/application_items/project_numbers
begin
--   Manifest
--     APPLICATION ITEM: PROJECT_NUMBERS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>666
,p_default_id_offset=>90826491306730853
,p_default_owner=>'PROD'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(20767527607951689)
,p_name=>'PROJECT_NUMBERS'
,p_protection_level=>'I'
,p_item_comment=>'ListAgg of project numbers assigned to logged in user'
);
wwv_flow_api.component_end;
end;
/
