create or replace package body cwip_rec_payment_emails as

PROCEDURE SEND_REC_PAYMENT_ACTION_REQUIRED_EMAIL  (P_PAYMENT_RECOMMENDATION_ID NUMBER, 
												   P_PERSON_ID NUMBER, 
												   P_PERSON_TYPE     VARCHAR2
                                                   ,P_HISTORY_ID  Number)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
l_express_link						    varchar2(1000);
l_hash                                  varchar2(255);
begin

--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Approver details  
CASE	 P_PERSON_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_ACTION_REQUIRED_EMAIL_TEMP';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
        
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_ACTION_REQUIRED_EMAIL_TEMP';
				
		-- set Application Link
               
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1:' ;
End Case;
			
   -- prepare Express Link
    l_hash := apex_util.get_hash(apex_t_varchar2(P_PAYMENT_RECOMMENDATION_ID , P_HISTORY_ID));

           
  l_express_link :=  'https://ifinance.dct.gov.ae:8004/dct/prod/r/cwippay/express-payment-recommendation-approve-reject?p38_hash='|| l_hash ;


    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||  
                '    , "EXPRESS_LINK":'          		    || apex_json.stringify(l_express_link)      				||  
                '}' 
                );

apex_mail.push_queue();
    
end SEND_REC_PAYMENT_ACTION_REQUIRED_EMAIL;

-- *****************************************************************************
PROCEDURE SEND_REC_PAYMENT_REJECT_EMAIL  (P_PAYMENT_RECOMMENDATION_ID NUMBER, 
												   P_PERSON_ID NUMBER, 
												   P_PERSON_TYPE     VARCHAR2,
                                                   P_COMMENT         VARCHAR2)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
begin


--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Approver details  
CASE	 P_PERSON_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_FINAL_REJECT_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_FINAL_REJECT_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
    
    
    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "COMMENT":'                   		|| apex_json.stringify(P_COMMENT)                          ||
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||    
                '}' 
                );

apex_mail.push_queue();
    
end SEND_REC_PAYMENT_REJECT_EMAIL;

-- *****************************************************************************
PROCEDURE SEND_REC_PAYMENT_FINAL_APPROVE_EMAIL  (P_PAYMENT_RECOMMENDATION_ID NUMBER, 
												   P_PERSON_ID NUMBER, 
												   P_PERSON_TYPE     VARCHAR2,
                                                   P_COMMENT         VARCHAR2)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
begin


--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Approver details  
CASE	 P_PERSON_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_FINAL_APPROVE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_FINAL_APPROVE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
    
    
    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "COMMENT":'                   		|| apex_json.stringify(P_COMMENT)                          ||
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||    
                '}' 
                );

apex_mail.push_queue();
    
end SEND_REC_PAYMENT_FINAL_APPROVE_EMAIL;

-- *****************************************************************************

PROCEDURE SEND_REC_PAYMENT_FYI_APPROVE_EMAIL  (P_PAYMENT_RECOMMENDATION_ID NUMBER, 
												   P_PERSON_ID NUMBER, 
												   P_PERSON_TYPE     VARCHAR2,
                                                   P_COMMENT         VARCHAR2)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
begin


--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Approver details  
CASE	 P_PERSON_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_APPROVE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_APPROVE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
    
    
    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "COMMENT":'                   		|| apex_json.stringify(P_COMMENT)                          ||
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||    
                '}' 
                );

apex_mail.push_queue();
    
end SEND_REC_PAYMENT_FYI_APPROVE_EMAIL;

--******************************************************************************
-- ********************   END **************************************************

PROCEDURE SEND_REC_PAYMENT_MORE_INFO_EMAIL  (	P_PAYMENT_RECOMMENDATION_ID 	NUMBER
											,	P_PERSON_SENDER_ID 				NUMBER
											, 	P_PERSON_SENDER_TYPE     		VARCHAR2
											,   P_PERSON_RECEIVER_ID 			NUMBER
											, 	P_PERSON_RECEIVER_TYPE     		VARCHAR2
											,	P_COMMENT  						VARCHAR2)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_EmailSenderDetailType					EmailSenderDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
begin


--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Sender details  
CASE	 P_PERSON_SENDER_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailSenderDetailType
				from employees_v e
				where e.person_id = P_PERSON_SENDER_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailSenderDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_SENDER_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
     --3) Get Receiver details  
CASE	 P_PERSON_RECEIVER_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_RECEIVER_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_RECEIVER_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
    
    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "COMMENT":'                   		|| apex_json.stringify(P_COMMENT)                          ||
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
				'    , "EMP_TITLE":'                   		|| apex_json.stringify(l_EmailSenderDetailType.title)                                    ||
                '    , "EMP_NAME":'                   		|| apex_json.stringify(l_EmailSenderDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||    
                '}' 
                );

apex_mail.push_queue();
    
end SEND_REC_PAYMENT_MORE_INFO_EMAIL;

-- *****************************************************************************
-- *****************************************************************************
PROCEDURE SEND_REC_PAYMENT_MORE_INFO_UPDATES_EMAIL  (	P_PAYMENT_RECOMMENDATION_ID 	NUMBER
											,	P_PERSON_SENDER_ID 				NUMBER
											, 	P_PERSON_SENDER_TYPE     		VARCHAR2
											,   P_PERSON_RECEIVER_ID 			NUMBER
											, 	P_PERSON_RECEIVER_TYPE     		VARCHAR2
											,	P_COMMENT  						VARCHAR2)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_EmailSenderDetailType					EmailSenderDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
begin


--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Sender details  
CASE	 P_PERSON_SENDER_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailSenderDetailType
				from employees_v e
				where e.person_id = P_PERSON_SENDER_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_UPDATE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailSenderDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_SENDER_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_UPDATE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
     --3) Get Receiver details  
CASE	 P_PERSON_RECEIVER_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_RECEIVER_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_UPDATE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_RECEIVER_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_MORE_INFORMATION_UPDATE_EMAIL';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
    
    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "COMMENT":'                   		|| apex_json.stringify(P_COMMENT)                          ||
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
				'    , "EMP_TITLE":'                   		|| apex_json.stringify(l_EmailSenderDetailType.title)                                    ||
                '    , "EMP_NAME":'                   		|| apex_json.stringify(l_EmailSenderDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||    
                '}' 
                );

apex_mail.push_queue();
    
end SEND_REC_PAYMENT_MORE_INFO_UPDATES_EMAIL;

-- *****************************************************************************
PROCEDURE SEND_DELEGATE_EMAIL  (P_PAYMENT_RECOMMENDATION_ID    NUMBER, P_PERSON_FROM_ID NUMBER , P_PERSON_TO_ID NUMBER)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_EmailSenderDetailType           		EmailReceiverDetailType;
l_send_to_email                     	varchar2(255);
l_email_template						varchar2(255);
begin


--1) get Payment Recommendation details

			SELECT
			pr.project_name                                                                     project,
			pr.contract_description                                                             contract_description,
			pr.vendor_name                                                                      Contracting_Party,
			trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
			trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
			trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
			pr.payment_type                                                                     payment_type,
			pr.evaluation_method                                                                Payment_method,
			pr.payment_number                                                                   payment_number,
			pr.contract_reference                                                               contract_reference,
			pr.contract_number                                                                  Purchase_order,
			cont.contract_days                                                                  Agreement_Duration,
			cont.end_date                                                                       Completion_Date,
			pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
			trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
			trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
			pr.scope_of_work                                                                    scope_of_work,
			pr.remark                                                                           remark   
		into 	l_PaymentRecommendationDetailsType
		FROM
			cwip_payment_recommendation_v  pr, cwip_contracts_v cont
		where pr.contract_number = cont.contract_number
		and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Approver details                           
    select e.title , e.full_name_en , e.email 
    into l_EmailReceiverDetailType
    from employees_v e
    where e.person_id = P_PERSON_TO_ID;

 --3) Get Sender details                           
    select e.title , e.full_name_en , e.email 
    into l_EmailSenderDetailType
    from employees_v e
    where e.person_id = P_PERSON_FROM_ID;
    
    
 --(4) Send Email to Delegated_to person
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;
	
		l_email_template := 'DELEGATE_TO_RECOMMENDATION_PAYMENT_EMAIL' ;
		
		apex_mail.send (
						p_to                 => l_send_to_email ,
						p_from               => 'ifinance@dctabudhabi.ae',
						p_template_static_id => l_email_template,
						p_placeholders       => '{'         ||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "APPROVER_TITL":'                    || apex_json.stringify(l_EmailReceiverDetailType.title)                           ||
                '    , "APPROVER_EMP_NAME":'                || apex_json.stringify(l_EmailReceiverDetailType.full_name_en)              ||
                '    , "DELEGATED_FROM_TITLE":'             || apex_json.stringify(l_EmailSenderDetailType.title)                      ||
                '    , "DELEGATED_FROM_EMP_NAME":'          || apex_json.stringify(l_EmailSenderDetailType.full_name_en)                           ||
                '    , "APPLICATION_LINK":'                 || apex_json.stringify('https://ifinance.dct.gov.ae:8004/dct/f?p=103:1')      ||    
						'}' 
						);

--(5) Send Email to Delegated_From person
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailSenderDetailType.email)
    into l_send_to_email 
    from dual;
	
		l_email_template := 'DELEGATE_FROM_RECOMMENDATION_PAYMENT_EMAIL' ;
		
		apex_mail.send (
						p_to                 => l_send_to_email ,						
						p_from               => 'ifinance@dctabudhabi.ae',
						p_template_static_id => l_email_template,
						p_placeholders       => '{'         ||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "APPROVER_TITL":'                    || apex_json.stringify(l_EmailSenderDetailType.title)                           ||
                '    , "APPROVER_EMP_NAME":'                || apex_json.stringify(l_EmailSenderDetailType.full_name_en)              		||
                '    , "DELEGATE_TO_EMP_TITLE":'            || apex_json.stringify(l_EmailReceiverDetailType.title)                      ||
                '    , "DELEGATE_TO_EMP_NAME":'  	        || apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                           ||
                '    , "APPLICATION_LINK":'                 || apex_json.stringify('https://ifinance.dct.gov.ae:8004/dct/f?p=103:1')      ||    
						'}' 
						);

 apex_mail.push_queue();
 
end SEND_DELEGATE_EMAIL;

--// ***************************************************************************

-- *****************************************************************************
-- *****************************************************************************
PROCEDURE SEND_COMMENT_EMAIL  (	P_PAYMENT_RECOMMENDATION_ID 	NUMBER
											,	P_PERSON_SENDER_ID 				NUMBER
											, 	P_PERSON_SENDER_TYPE     		VARCHAR2
											,   P_PERSON_RECEIVER_ID 			NUMBER
											, 	P_PERSON_RECEIVER_TYPE     		VARCHAR2
											,	P_COMMENT  						VARCHAR2)
is

l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
l_EmailReceiverDetailType           	EmailReceiverDetailType;
l_EmailSenderDetailType					EmailSenderDetailType;
l_send_to_email                     	varchar2(255);
l_email_template                    	varchar2(255);
l_application_link						varchar2(1000);
begin


--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;

 --2) Get Sender details  
CASE	 P_PERSON_SENDER_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailSenderDetailType
				from employees_v e
				where e.person_id = P_PERSON_SENDER_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'COMMENT_ON_PAYMENT_RECOMMENDATION';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailSenderDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_SENDER_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'COMMENT_ON_PAYMENT_RECOMMENDATION';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
     --3) Get Receiver details  
CASE	 P_PERSON_RECEIVER_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_RECEIVER_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'COMMENT_ON_PAYMENT_RECOMMENDATION';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=904:1' ;
	
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_RECEIVER_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'COMMENT_ON_PAYMENT_RECOMMENDATION';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
End Case;
			
    
    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;

apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                '    , "COMMENT":'                   		|| apex_json.stringify(P_COMMENT)                          ||
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
				'    , "EMP_TITLE":'                   		|| apex_json.stringify(l_EmailSenderDetailType.title)                                    ||
                '    , "EMP_NAME":'                   		|| apex_json.stringify(l_EmailSenderDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||    
                '}' 
                );

apex_mail.push_queue();
    
end SEND_COMMENT_EMAIL;

-- *****************************************************************************
--************************************ End *************************************
procedure Remider_email (P_PAYMENT_RECOMMENDATION_ID   in number ,P_PERSON_ID NUMBER,P_PERSON_TYPE     VARCHAR2, P_HISTORY_ID  Number) as

	l_PaymentRecommendationDetailsType      PaymentRecommendationDetailsType;
	l_EmailReceiverDetailType           	EmailReceiverDetailType;
	l_send_to_email                     	varchar2(255);
	l_email_template                    	varchar2(255);
	l_application_link						varchar2(1000);
	l_express_link						    varchar2(1000);
	l_hash                                  varchar2(255);
begin




--1) get Payment Recommendation details

    SELECT
    pr.project_name                                                                     project,
    pr.contract_description                                                             contract_description,
    pr.vendor_name                                                                      Contracting_Party,
    trim(to_char(pr.initial_contract_amount, '99,999,999,999.99'))                      initial_contract_amount,
    trim(to_char(nvl(pr.DCT_CONTRACT_VARIATION_AMOUNT , pr.CONTRACT_VARIATION_AMOUNT), '99,999,999,999.99')) Approved_Variations,
    trim(to_char(pr.contract_amount,'99,999,999,999.99'))                               Revised_Contract_Amount,
    pr.payment_type                                                                     payment_type,
    pr.evaluation_method                                                                Payment_method,
    pr.payment_number                                                                   payment_number,
    pr.contract_reference                                                               contract_reference,
    pr.contract_number                                                                  Purchase_order,
    cont.contract_days                                                                  Agreement_Duration,
    cont.end_date                                                                       Completion_Date,
    pr.valuation_period_from                                                            Cumulative_Certified_to_Date,
    trim(to_char(pr.cumulative_cerified_amount, '99,999,999,999.99'))                   Previously_Certified,
    trim(to_char(pr.net_amount_payable,'99,999,999,999.99'))                            Net_Payable_Amount_excluding_VAT,
    pr.scope_of_work                                                                    scope_of_work,
    pr.remark                                                                           remark   
into 	l_PaymentRecommendationDetailsType
FROM
    cwip_payment_recommendation_v  pr, cwip_contracts_v cont
where pr.contract_number = cont.contract_number
and pr.payment_recommendation_id = P_PAYMENT_RECOMMENDATION_ID;




--2) Get Approver details  
CASE	 P_PERSON_TYPE
	When 'INT'	Then
		-- Pending Person from Internal Users
		
				select e.title , e.full_name_en , e.email 
				into l_EmailReceiverDetailType
				from employees_v e
				where e.person_id = P_PERSON_ID;
		
		-- Email Template for Internal USER
				l_email_template := 'REMINDER_APPROVE_REJECT_CWIP_PAYMENTS';
				
		-- set Application Link
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1' ;
        
	when 'EXT' Then
		-- Pending Person from External
			
				select TITLE, FULL_NAME_EN, EMAIL 
				into l_EmailReceiverDetailType
				from dct_ext_users
				where USER_ID = P_PERSON_ID;
				
		-- Email Template for Internal USER (currently,We use the same Template)
				l_email_template := 'PAYMENT_RECOMMENDATION_ACTION_REQUIRED_EMAIL_TEMP';
				
		-- set Application Link
               
			l_application_link := 'https://ifinance.dct.gov.ae:8004/dct/f?p=130:1:' ;
End Case;
			
   -- prepare Express Link
    l_hash := apex_util.get_hash(apex_t_varchar2(P_PAYMENT_RECOMMENDATION_ID , P_HISTORY_ID));

           
  l_express_link :=  'https://ifinance.dct.gov.ae:8004/dct/prod/r/cwippay/express-payment-recommendation-approve-reject?p38_hash='|| l_hash ;


    --(2) get Send To EMail
   Select decode(dct_util.get_send_test_email_by_app(NV('APP_ID')) , 
                            'Y' , dct_util.get_test_email_by_app(NV('APP_ID')) , 
                            'N' , l_EmailReceiverDetailType.email)
    into l_send_to_email 
    from dual;



apex_mail.send (
                p_to                 => l_send_to_email ,
                p_from               => 'ifinance@dctabudhabi.ae',
                p_template_static_id => l_email_template		,
                p_placeholders       => '{'         		||
                '     "PROJECT":'              				|| apex_json.stringify(l_PaymentRecommendationDetailsType.project)                         ||
                '    , "CONTRACT_DESCRIPTION":'          	|| apex_json.stringify(l_PaymentRecommendationDetailsType.contract_description)            ||
                '    , "CONTRACTING_PARTY":'                || apex_json.stringify(l_PaymentRecommendationDetailsType.Contracting_Party)               ||
                '    , "INITIAL_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.initial_contract_amount))   ||
                '    , "APPROVED_VARIATIONS":'              || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Approved_Variations))       ||
                '    , "REVISED_CONTRACT_AMOUNT":'          || apex_json.stringify(trim(l_PaymentRecommendationDetailsType.Revised_Contract_Amount))   ||
                '    , "PAYMENT_TYPE":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.payment_type)                    ||
				'    , "PAYMENT_METHOD":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Payment_method)                  ||
				'    , "PAYMENT_NUMBER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.payment_number)                  ||
				'    , "CONTRACT_REFERENCE":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.contract_reference)              ||
				'    , "PURCHASE_ORDER":'                   || apex_json.stringify(l_PaymentRecommendationDetailsType.Purchase_order)                  ||
				'    , "AGREEMENT_DURATION":'               || apex_json.stringify(l_PaymentRecommendationDetailsType.Agreement_Duration)              ||
				'    , "COMPLETION_DATE":'                  || apex_json.stringify(l_PaymentRecommendationDetailsType.Completion_Date)                 ||
				'    , "CUMULATIVE_CERTIFIED_TO_DATE":'     || apex_json.stringify(l_PaymentRecommendationDetailsType.Cumulative_Certified_to_Date)    ||
				'    , "PREVIOUSLY_CERTIFIED":'             || apex_json.stringify(l_PaymentRecommendationDetailsType.Previously_Certified)            ||
				'    , "NET_PAYABLE_AMOUNT_EXCLUDING_VAT":' || apex_json.stringify(l_PaymentRecommendationDetailsType.Net_Payable_Amount_excluding_VAT)||
				'    , "SCOPE_OF_WORK":'                   	|| apex_json.stringify(l_PaymentRecommendationDetailsType.scope_of_work)                   ||
				'    , "REMARK":'                   		|| apex_json.stringify(l_PaymentRecommendationDetailsType.remark)                          ||
                
                '    , "APPROVER_TITLE":'                   || apex_json.stringify(l_EmailReceiverDetailType.title)                                    ||
                '    , "APPROVER_NAME":'                   	|| apex_json.stringify(l_EmailReceiverDetailType.full_name_en)                             ||
				
                '    , "APPLICATION_LINK":'          		|| apex_json.stringify(l_application_link)      				||  
                '    , "EXPRESS_LINK":'          		    || apex_json.stringify(l_express_link)      				||  
                '}' 
                );

apex_mail.push_queue();
    
end Remider_email;


end cwip_rec_payment_emails;