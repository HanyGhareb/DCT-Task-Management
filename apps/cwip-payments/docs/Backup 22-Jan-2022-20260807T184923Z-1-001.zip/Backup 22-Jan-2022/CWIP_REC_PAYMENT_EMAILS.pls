create or replace package cwip_rec_payment_emails as 

    --(1) Define Payment Recommendation Details Record
    TYPE PaymentRecommendationDetailsType
    IS RECORD ( 
				project										cwip_payment_recommendation_v.project_name%TYPE,
				contract_description						cwip_payment_recommendation_v.contract_description%TYPE,
				Contracting_Party							cwip_payment_recommendation_v.vendor_name%TYPE,
				initial_contract_amount						varchar2(50),   --cwip_payment_recommendation_v.initial_contract_amount%TYPE,
				Approved_Variations							varchar2(50),   --cwip_payment_recommendation_v.initial_contract_amount%TYPE,
				Revised_Contract_Amount						varchar2(50),   --cwip_payment_recommendation_v.contract_amount%TYPE,
				payment_type								cwip_payment_recommendation_v.payment_type%TYPE,
				Payment_method								cwip_payment_recommendation_v.evaluation_method%TYPE,
				payment_number								cwip_payment_recommendation_v.payment_number%TYPE,
				contract_reference							cwip_payment_recommendation_v.contract_reference%TYPE,
				Purchase_order								cwip_payment_recommendation_v.contract_number%TYPE,
			
				Agreement_Duration							cwip_contracts_v.contract_days%TYPE,
				Completion_Date								cwip_contracts_v.end_date%TYPE,
				
				Cumulative_Certified_to_Date				cwip_payment_recommendation_v.valuation_period_from%TYPE,
				Previously_Certified						varchar2(50),   --cwip_payment_recommendation_v.cumulative_cerified_amount%TYPE,
				Net_Payable_Amount_excluding_VAT			varchar2(50),   --cwip_payment_recommendation_v.net_amount_payable%TYPE,
				scope_of_work								cwip_payment_recommendation_v.scope_of_work%TYPE,
				remark										cwip_payment_recommendation_v.remark%TYPE  
            );	
            
    --(2) Define Mail Receiver Details Record
    TYPE EmailReceiverDetailType
    IS RECORD ( TITLE                           employees_v.title%TYPE , 
                FULL_NAME_EN                    employees_v.full_name_en%TYPE , 
                EMAIL                           employees_v.email%TYPE
            );    
            
     --(3) Define Mail Sender Details Record
    TYPE EmailSenderDetailType
    IS RECORD ( TITLE                           employees_v.title%TYPE , 
                FULL_NAME_EN                    employees_v.full_name_en%TYPE , 
                EMAIL                           employees_v.email%TYPE
            );           
            
--******************************************************************************
PROCEDURE SEND_REC_PAYMENT_ACTION_REQUIRED_EMAIL     (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_ID NUMBER, P_PERSON_TYPE     VARCHAR2,P_HISTORY_ID  Number);
PROCEDURE SEND_REC_PAYMENT_REJECT_EMAIL              (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_ID NUMBER, P_PERSON_TYPE     VARCHAR2,P_COMMENT  VARCHAR2);
PROCEDURE SEND_REC_PAYMENT_FINAL_APPROVE_EMAIL       (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_ID NUMBER, P_PERSON_TYPE     VARCHAR2,P_COMMENT  VARCHAR2);
PROCEDURE SEND_REC_PAYMENT_FYI_APPROVE_EMAIL         (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_ID NUMBER, P_PERSON_TYPE     VARCHAR2,P_COMMENT  VARCHAR2);


PROCEDURE SEND_REC_PAYMENT_MORE_INFO_EMAIL           (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_SENDER_ID NUMBER, P_PERSON_SENDER_TYPE     VARCHAR2,
                                                        P_PERSON_RECEIVER_ID NUMBER, P_PERSON_RECEIVER_TYPE     VARCHAR2,P_COMMENT  VARCHAR2);

PROCEDURE SEND_REC_PAYMENT_MORE_INFO_UPDATES_EMAIL   (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_SENDER_ID NUMBER, P_PERSON_SENDER_TYPE     VARCHAR2,
                                                        P_PERSON_RECEIVER_ID NUMBER, P_PERSON_RECEIVER_TYPE     VARCHAR2,P_COMMENT  VARCHAR2);
                                                        
PROCEDURE SEND_DELEGATE_EMAIL                        (P_PAYMENT_RECOMMENDATION_ID NUMBER   , P_PERSON_FROM_ID NUMBER , P_PERSON_TO_ID NUMBER);                            

PROCEDURE SEND_COMMENT_EMAIL                         (P_PAYMENT_RECOMMENDATION_ID NUMBER, P_PERSON_SENDER_ID NUMBER, P_PERSON_SENDER_TYPE     VARCHAR2,
                                                        P_PERSON_RECEIVER_ID NUMBER, P_PERSON_RECEIVER_TYPE     VARCHAR2,P_COMMENT  VARCHAR2);

procedure Remider_email                               (P_PAYMENT_RECOMMENDATION_ID   in number ,P_PERSON_ID NUMBER,P_PERSON_TYPE     VARCHAR2, P_HISTORY_ID  Number);                                                        

END cwip_rec_payment_emails;