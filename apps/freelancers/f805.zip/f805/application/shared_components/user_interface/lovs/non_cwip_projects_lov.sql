prompt --application/shared_components/user_interface/lovs/non_cwip_projects_lov
begin
--   Manifest
--     NON CWIP PROJECTS LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>805
,p_default_id_offset=>0
,p_default_owner=>'PROD'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(36876687709051729)
,p_lov_name=>'NON CWIP PROJECTS LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  PROJECT.PROJECT_NAME    ||',
'        '' (''                    ||',
'        PROJECT.PROJECT_NUMBER  ||',
'        '')''                         as PROJECT_NAME,',
'    PROJECT.PROJECT_NUMBER as PROJECT_NUMBER ',
' from PROJECT PROJECT',
' where project_type in (''Operational'' , ''Non GL Integrated'')',
' order by project_number;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PROJECT_NUMBER'
,p_display_column_name=>'PROJECT_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'PROJECT_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
