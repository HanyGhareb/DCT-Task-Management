prompt --application/shared_components/user_interface/lovs/copy_of_organizations_all_lov
begin
--   Manifest
--     COPY OF ORGANIZATIONS ALL LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>101
,p_default_id_offset=>67985499647402269
,p_default_owner=>'PROD'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(698887168233800)
,p_lov_name=>'COPY OF ORGANIZATIONS ALL LOV'
,p_reference_id=>2483802706258656
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select org_name_en , org_id',
'from dct_hr_organizations'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ORG_ID'
,p_display_column_name=>'ORG_NAME_EN'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ORG_NAME_EN'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
