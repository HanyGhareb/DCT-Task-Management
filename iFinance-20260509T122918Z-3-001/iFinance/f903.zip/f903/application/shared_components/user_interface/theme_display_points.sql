prompt --application/shared_components/user_interface/theme_display_points
begin
--   Manifest
--     THEME DISPLAY POINTS: 903
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1448684262833497
,p_default_application_id=>114
,p_default_id_offset=>9604171250607172
,p_default_owner=>'DEV'
);
null;
wwv_flow_api.component_end;
end;
/
