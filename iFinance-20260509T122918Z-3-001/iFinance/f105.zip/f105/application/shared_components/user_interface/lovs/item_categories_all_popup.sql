prompt --application/shared_components/user_interface/lovs/item_categories_all_popup
begin
--   Manifest
--     ITEM CATEGORIES ALL POPUP
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>803
,p_default_id_offset=>213284032389184632
,p_default_owner=>'PROD'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(11222306391152611)
,p_lov_name=>'ITEM CATEGORIES ALL POPUP'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  x.CATEGORY_NAME , x.CATEGORY_ID ,',
'        (select y.CATEGORY_NAME from dp_item_categories y where x.parent_category_id = y.category_id) Parent_Category',
'from dp_item_categories x',
'where x.order_level = 233'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CATEGORY_ID'
,p_display_column_name=>'CATEGORY_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'CATEGORY_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(11222654382152616)
,p_query_column_name=>'CATEGORY_NAME'
,p_heading=>'Category Name'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.create_list_of_values_cols(
 p_id=>wwv_flow_api.id(11223008615152616)
,p_query_column_name=>'PARENT_CATEGORY'
,p_heading=>'Parent Category'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_api.component_end;
end;
/
