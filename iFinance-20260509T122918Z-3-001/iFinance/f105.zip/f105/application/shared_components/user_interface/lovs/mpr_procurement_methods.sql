prompt --application/shared_components/user_interface/lovs/mpr_procurement_methods
begin
--   Manifest
--     MPR PROCUREMENT METHODS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>803
,p_default_id_offset=>213284032389184632
,p_default_owner=>'PROD'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(63846578782137379)
,p_lov_name=>'MPR PROCUREMENT METHODS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select MPR_PROCUREMENT_METHODS.PROCUREMENT_METHOD_NAME as PROCUREMENT_METHOD_NAME,',
'    MPR_PROCUREMENT_METHODS.ID as ID ',
' from MPR_PROCUREMENT_METHODS MPR_PROCUREMENT_METHODS'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'PROCUREMENT_METHOD_NAME'
,p_default_sort_column_name=>'PROCUREMENT_METHOD_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
