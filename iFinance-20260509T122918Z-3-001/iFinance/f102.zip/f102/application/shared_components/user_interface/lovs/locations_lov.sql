prompt --application/shared_components/user_interface/lovs/locations_lov
begin
--   Manifest
--     LOCATIONS LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'PROD'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(55356292753529614)
,p_lov_name=>'LOCATIONS LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(desc_E_user , desc_e) , code',
'from dct_employees_lookups',
' where lookup_name = ''Locations Codes'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODE'
,p_display_column_name=>'NVL(DESC_E_USER,DESC_E)'
,p_default_sort_column_name=>'NVL(DESC_E_USER,DESC_E)'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
