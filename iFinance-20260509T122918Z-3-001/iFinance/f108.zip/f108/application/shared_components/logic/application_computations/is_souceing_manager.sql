prompt --application/shared_components/logic/application_computations/is_souceing_manager
begin
--   Manifest
--     APPLICATION COMPUTATION: IS_SOUCEING_MANAGER
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>500
,p_default_id_offset=>354480484490134169
,p_default_owner=>'PROD'
);
wwv_flow_api.create_flow_computation(
 p_id=>wwv_flow_api.id(52295717107545464)
,p_computation_sequence=>20
,p_computation_item=>'IS_SOUCEING_MANAGER'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(distinct person_id)',
'from DCT_DATA_ACCESS_ASSIGNMENT',
'where entity_id = 30    -- 30 for SOURCING_MANAGER Role',
'and status = ''A''',
'and sysdate between start_date and nvl(end_date , sysdate+ 100)',
'and person_id = :PERSON_ID;'))
,p_computation_error_message=>'Error in IS_SOUCEING_MANAGER application Item '
);
wwv_flow_api.component_end;
end;
/
