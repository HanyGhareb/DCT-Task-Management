prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 810
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>810
,p_default_id_offset=>110610876490006977
,p_default_owner=>'PROD'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(12986507019762217)
,p_group_name=>'Administration'
);
wwv_flow_api.component_end;
end;
/
