prompt --application/shared_components/user_interface/lovs/vr_numbers_by_id_all
begin
--   Manifest
--     VR NUMBERS BY ID-ALL
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>142
,p_default_id_offset=>0
,p_default_owner=>'PROD'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(194969230938467993)
,p_lov_name=>'VR NUMBERS BY ID-ALL'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select REQUEST_NO , REQUEST_ID',
'from vr_requests'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'REQUEST_ID'
,p_display_column_name=>'REQUEST_NO'
,p_default_sort_column_name=>'REQUEST_NO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
