prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 166
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1200569973923101
,p_default_application_id=>120
,p_default_id_offset=>143576171933264960
,p_default_owner=>'PROD'
);
wwv_flow_api.create_page_group(
 p_id=>wwv_flow_api.id(24637802578319225)
,p_group_name=>'Administration'
);
wwv_flow_api.component_end;
end;
/
